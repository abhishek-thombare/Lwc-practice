import { LightningElement } from 'lwc';

export default class DT_EditSortActions extends LightningElement {}