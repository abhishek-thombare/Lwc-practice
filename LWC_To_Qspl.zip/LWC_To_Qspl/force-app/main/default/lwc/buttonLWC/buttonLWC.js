import { LightningElement, track } from 'lwc';

export default class ButtonLWC extends LightningElement {
    

    //Basic Button
    clickedButtonLabel;
    handleClick(event) {
        this.clickedButtonLabel = event.target.label;
    }

    handleClick1(event) {
        this.clickedButtonLabel = event.target.label;
    }
    //Buton with Icon Custom OnCLick
    toggleIconName = 'utility:preview';
    toggleButtonLabel = 'Hide content';
    @track greekLetter;

    // when the component is first initialized assign an initial value to the `greekLetter` variable
    connectedCallback() {
        this.greekLetter = this.getRandomGreekLetter();
    }

    // Handles click on the 'Show/hide content' button
    handleToggleClick() {
        // retrieve the classList from the specific element
        const contentBlockClasslist = this.template.querySelector(
            '.lgc-id_content-toggle'
        ).classList;
        // toggle the hidden class
        contentBlockClasslist.toggle('slds-hidden');

        // if the current icon-name is `utility:preview` then change it to `utility:hide`
        if (this.toggleIconName === 'utility:preview') {
            this.toggleIconName = 'utility:hide';
            this.toggleButtonLabel = 'Reveal content';
        } else {
            this.toggleIconName = 'utility:preview';
            this.toggleButtonLabel = 'Hide content';
        }
    }

    // Handles click on the 'Random greek letter' button
    handleRandomClick() {
        this.greekLetter = this.getRandomGreekLetter();
    }

    // internal only method of this example component
    // :: this generates a random greek letter string that is inserted into the template
    getRandomGreekLetter() {
        // retrieve a random greek letter from the array
        const letter = this.greek[
            Math.floor(Math.random() * this.greek.length)
        ];

        // create a temporary <textarea> element using the DOMParser
        // :: this allows for the pretty formatting using the HTML character entities such as `&alpha;`
        // :: this allows the browser to automatically convert the string to proper HTML
        const textarea = new DOMParser().parseFromString(
            `<textarea>${letter} [ &${letter}; ]</textarea>`,
            'text/html'
        ).body.firstChild;

        // return the final converted value for output in our component
        return textarea.value;
    }

    // list of greek letter names
    greek = [
        'alpha',
        'theta',
        'tau',
        'beta',
        'vartheta',
        'pi',
        'upsilon',
        'gamma',
        'iota',
        'varpi',
        'phi',
        'delta',
        'kappa',
        'rho',
        'varphi',
        'epsilon',
        'lambda',
        'varrho',
        'chi',
        'varepsilon',
        'mu',
        'sigma',
        'psi',
        'zeta',
        'nu',
        'varsigma',
        'omega',
        'eta',
        'xi',
        'Gamma',
        'Lambda',
        'Sigma',
        'Psi',
        'Delta',
        'Xi',
        'Upsilon',
        'Omega',
        'Theta',
        'Pi',
        'Phi',
    ];


    //Basic Button Group
    buttonStatefulState = false;
    buttonIconStatefulState = false;

    handleButtonStatefulClick() {
        this.buttonStatefulState = !this.buttonStatefulState;
    }

    handleButtonIconStatefulClick() {
        this.buttonIconStatefulState = !this.buttonIconStatefulState;
    }


    //Button Icon Stateful
    @track likeState = false;
    @track answerState = false;
    @track likeStateSize01 = false;
    @track likeStateSize02 = false;
    @track likeStateSize03 = false;
    @track likeStateSize04 = false;
    @track likeStateDisabled = false;
    @track answerStateDisabled = false;

    handleLikeButtonClick() {
        this.likeState = !this.likeState;
    }

    handleAnswerButtonClick() {
        this.answerState = !this.answerState;
    }

    handleLikeButtonSizeClick(event) {
        const buttonNumber = event.target.dataset.buttonNumber;

        this[`likeStateSize${buttonNumber}`] = !this[
            `likeStateSize${buttonNumber}`
        ];
    }

    handleLikeButtonDisabledClick() {
        this.likeStateDisabled = !this.likeStateDisabled;
    }

    handleAnswerButtonDisabledClick() {
        this.answerStateDisabled = !this.answerStateDisabled;
    }



     //Button Icon Stateful with border variant
     likeStateInverse = false;
     answerStateInverse = false;
     likeStateFilled = false;
     answerStateFilled = false;
 
     handleLikeButtonInverseClick() {
         this.likeStateInverse = !this.likeStateInverse;
     }
 
     handleAnswerButtonInverseClick() {
         this.answerStateInverse = !this.answerStateInverse;
     }
 
     handleLikeButtonFilledClick() {
         this.likeStateFilled = !this.likeStateFilled;
     }
 
     handleAnswerButtonFilledClick() {
         this.answerStateFilled = !this.answerStateFilled;
     }
     
     

     //Stateful Button
     isSelected = false;

     handleClick2() {
         this.isSelected = !this.isSelected;
     }

     //Statful Button With Inverse Variant
     isSelected1 = false;

    handleClick3() {
        this.isSelected1 = !this.isSelected1;
    }




}

export const alertFn = () => {
    alert('Hello');
 }