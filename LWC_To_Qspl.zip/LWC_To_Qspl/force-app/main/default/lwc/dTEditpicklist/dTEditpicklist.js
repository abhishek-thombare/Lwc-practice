import { LightningElement } from 'lwc';

export default class DTEditpicklist extends LightningElement {}