import { LightningElement ,api, wire, track} from 'lwc';
import searchAccounts from '@salesforce/apex/AccountController.searchAccount';
const columnList = [
    {label: 'Id', fieldName: 'Id', editable: true},
    {label: 'Name', fieldName: 'Name', editable: true},
    {label: 'Website', fieldName: 'Website', editable: true},
    {label: 'Industry', fieldName: 'Industry', editable: true}
];


const columndata =[
    {
        label: 'View',
        type: 'button-icon',
        initialWidth: 75,
        typeAttributes: {
            iconName: 'action:preview',
            title: 'Preview',
            variant: 'border-filled',
            alternativeText: 'View'
        }
    },
    {
        label: 'Name',
        fieldName: 'Name',
        
    },
    {
        label: 'Phone',
        fieldName: 'Phone',
        
    },
    {
        label: 'Type',
        fieldName: 'Type',
        
    }
];



import { NavigationMixin } from 'lightning/navigation';

import getAccountList from '@salesforce/apex/AccountHelper.getAccountList';
export default class DatatableLWC extends LightningElement {
    
    //Basic DataTable
    
    @track columns = [
        {
            label: 'Account name',
            fieldName: 'Name',
            type: 'text',
            sortable: true,
           // editable: true
        },
        {
            label: 'Type',
            fieldName: 'Type',
            type: 'text',
            sortable: true,
            //editable: true
        },
        {
            label: 'Annual Revenue',
            fieldName: 'AnnualRevenue',
            type: 'Currency',
            sortable: true,
          //  editable: true
        },
        {
            label: 'Phone',
            fieldName: 'Phone',
            type: 'phone',
            sortable: true,
           // editable: true
        },
        {
            label: 'Website',
            fieldName: 'Website',
            type: 'url',
            sortable: true,
           // editable: true
        },
        {
            label: 'Rating',
            fieldName: 'Rating',
            type: 'test',
            sortable: true,
           // editable: true
        }
    ];
 
    @track error;
    @track accList ;
    @wire(getAccountList)
    wiredAccounts({
        error,
        data
    }) {
        if (data) {
            this.accList = data;
        } else if (error) {
            this.error = error;
        }
    }


  //DataTable With Row Number & Custom Search

    @track accountList;
    @track columnList = columnList;
    @track noRecordsFound = true;

    findAccountResult(event) {
        const accName = event.target.value;

        if(accName) {
            searchAccounts ( {accName}) 
            .then(result => {
                this.accountList = result;
                this.noRecordsFound = false;
            })
        } else {
            this.accountList = undefined;
            this.noRecordsFound = true;
        }
    }



  //Datatable Row Actions with View Button
         @track columndata = columndata;
         @track record = {};
         @track rowOffset = 0;
         @track data = {};
         @track bShowModal = false;
         @wire(getAccountList) parameters;
        // Row Action event to show the details of the record
        handleRowAction(event) {
           const row = event.detail.row;
           this.record = row;
           this.bShowModal = true; // display modal window
        }
 
    // to close modal window set 'bShowModal' tarck value as false
    closeModal() {
        this.bShowModal = false;
    }


    
    //Sorting DataTable Columns
    defaultSortDirection = 'asc';
    sortDirection = 'asc';
    sortedBy;
    // Used to sort the 'Age' column
    sortBy(field, reverse, primer) {
        const key = primer
            ? function(x) {
                  return primer(x[field]);
              }
            : function(x) {
                  return x[field];
              };

        return function(a, b) {
            a = key(a);
            b = key(b);
            return reverse * ((a > b) - (b > a));
        };
    }

    onHandleSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        const cloneData = [...this.columnList];

        cloneData.sort(this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1));
        this.columnList= cloneData;
        this.sortDirection = sortDirection;
        this.sortedBy = sortedBy;
    }








}