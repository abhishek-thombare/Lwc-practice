import { LightningElement,api } from 'lwc';

export default class EnrollCourse extends LightningElement {
    @api courseDetailInfo=
    {
    courseName:'Lightning Web Component',
    courseDuration:'30 Days',
    courseFee:'Free', 
    courseRating:'*****',
    bannerImg: 'https://img-a.udemycdn.com/course/480x270/693700_d3eb_4.jpg'
    }

}