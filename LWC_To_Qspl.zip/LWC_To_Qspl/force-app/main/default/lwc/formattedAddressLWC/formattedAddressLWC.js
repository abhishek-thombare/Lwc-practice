import { LightningElement } from 'lwc';

export default class FormattedAddressLWC extends LightningElement {}