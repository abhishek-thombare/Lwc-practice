import { LightningElement } from 'lwc';

export default class FormatteddatetimeLWC extends LightningElement {}