import { LightningElement } from 'lwc';

export default class CheckboxGroupLWC extends LightningElement {

    value = ['option1'];
    val = ['opt2'];
    get options() {
        return [
            { label: 'Ross', value: 'option1' },
            { label: 'Rachel', value: 'option2' },
        ];
    }
    get selectedValues() {
        return this.value.join(',');
    }
    handleChange(e) {
        this.value = e.detail.value;
    }

    //option2
    get options2() {
        return [
            { label: 'Pune', value: 'optn1' },
            { label: 'Nashik', value: 'optn2' },
        ];
    }
    get selectedValues() {
        return this.value.join(',');
    }
    handle(z) {
        this.value = z.detail.value;
    }

       //option 3
    get options3() {
        return [
            { label: 'Samsung', value: 'opt1' },
            { label: 'Sony', value: 'opt2' },
        ];
    }
    get selectedValues() {
        return this.value.join(',');
    }
    handleme(u) {
        this.value = u.detail.value;
    }


}