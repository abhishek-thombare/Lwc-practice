import { LightningElement, track} from 'lwc';

export default class ComboboxBasic extends LightningElement {
    value = 'inProgress';
    value1 = '';
    @track isDisabled = false;

    get options() {
        return [
            { label: 'New', value: 'new' },
            { label: 'In Progress', value: 'inProgress' },
            { label: 'Finished', value: 'finished' },

        ];
    }

    handleChange(event) {
        this.value = event.detail.value; 
        
    }

    handleChange1(event) {
        this.value1 = event.detail.value;
    }

    //Wait action onclick wait for 10Ms
    DisableChange(event) {
        this.value = event.detail.value;
        this.isDisabled = true;
        setTimeout(() => {this.isDisabled = false;}, 10000);
    }


    //Onload timeout visibility
    clicktodisable = false;
    connectedCallback() 
    {
        setTimeout(() => {
           this.clicktodisable=true;
        }, 8000);    
    }


}