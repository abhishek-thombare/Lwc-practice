import { LightningElement } from 'lwc';

export default class DualListboxSimple extends LightningElement {
    _selected = [];
    
    //Onload timeout visibility
    clicktodisable = false;
    connectedCallback() 
    {
        setTimeout(() => {
            this.ready = true;
        }, 2000);    
     }


    get options() {
        return [
            { label: 'English', value: 'English' },
            { label: 'German', value: 'German' },
            { label: 'Spanish', value: 'Spanish' },
            { label: 'French', value: 'French' },
            { label: 'Italian', value: 'Italian' },
            { label: 'Japanese', value: 'Japanese' },
        ];
    }

    get selected() {
        return this._selected.length ? this._selected : 'none';
    }

    handleChange(e) {
        this._selected = e.detail.value;
    }

    //@ Auther: Abhishek_Thombare
    //Dual listbox shows some pre-selected options
    options1 = [];
    values1 = [];
    requiredOptions = [];

    connectedCallback() {
        const items = [];
        for (let i = 1; i <= 10; i++) {
            items.push({
                label: `Option ${i}`,
                value: `opt${i}`,
            });
        }
        this.options1.push(...items);
        this.values1.push(...['opt2', 'opt4', 'opt6']);
        this.requiredOptions.push(...['opt2', 'opt5']);
    }

}