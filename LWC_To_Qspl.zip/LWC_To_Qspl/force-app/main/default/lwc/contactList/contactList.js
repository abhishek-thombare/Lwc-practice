import { LightningElement } from 'lwc';

export default class ContactList extends LightningElement {}