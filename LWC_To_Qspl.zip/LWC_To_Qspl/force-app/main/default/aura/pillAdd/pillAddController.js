({
	
    
    

    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
   
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle" 
        component.set("v.isOpen", false);
    },
   
    likenClose: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('thanks for like Us :)');
        component.set("v.isOpen", false);
       
       
       
    },
   
    onRemovePill:function(component,event,helper){
        var pillId = event.getParam('item').id;
        var myJSON = JSON.stringify(pillId);
        var pills = component.get('v.items');
        //alert(pillId);
        for (var i = 0; i < pills.length; i++) {
           
            if (pillId === pills[i].id) {
                pills.splice(i, 1);
                break;
           }
        }
       
        component.set('v.items', pills);
    },
    AddRecordItem: function(component,event,helper){
        //items
        //event.
        var btn=event.getSource();
        var recordname=btn.get('v.name');
        var recordId=btn.get('v.value');
        var varIconName=btn.get('v.title');
       
        //alert(recordname);
        var pills = component.get('v.items');
       
        var AlreadyAdded='';
        for (var i = 0; i < pills.length; i++) {
            if (recordId === pills[i].id) {
                AlreadyAdded='true';
                break;
            }
        }
       
        if(AlreadyAdded==''){
            pills.push({
                type: 'icon',
                id: recordId,
                label: recordname,
                iconName: varIconName
            });
           
            component.set('v.items', pills);
           
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Success Message',
                message:'Item added successfully.',
                messageTemplate: 'Item added successfully.',
                duration:' 5000',
                key: 'info_alt',
                type: 'success',
                mode: 'pester'
            });
            toastEvent.fire();
        }else if(AlreadyAdded=='true'){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error Message',
                message:'Item already added.',
                messageTemplate: 'Item already added.',
                duration:' 1000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }       
       
       
    },
    SaveEvent: function(component,event,helper){
       
        var varMessage=component.find('TextMessage').get('v.value');
        var action= component.get("c.SaveRecord");
        var pills = component.get('v.items');
       
        action.setParams({
            'strMessage':varMessage
        });
       
        action.setCallback(this,function(response){
            var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                        var varIsSuccess=storeResponse.bIsSuccess;
                        var varMessage=storeResponse.Message;
                        var varRecordId=storeResponse.RecordId;
                        if(varIsSuccess==true){
                            helper.helperToastMessage(varMessage,'success');
                        }else{
                            helper.helperToastMessage(varMessage,'error');
                        }
                 }else if (state === "INCOMPLETE") {
                    alert('Response is Incompleted');
                }else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            alert("Error message: " +
                                  errors[0].message);
                        }
                    } else {
                        alert("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);
    },
    handleKeyUp: function (component, event) {
        var isEnterKey = event.keyCode === 13;
        var queryTerm = component.find('enter-search').get('v.value');
        if (isEnterKey) {
           
            component.set('v.issearching', true);
            var action = component.get("c.fetchData");
            action.setParams({
                'searchKeyWord':queryTerm
            });
            action.setCallback(this, function(response) {
               
                var state = response.getState();
               
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                   
                    // if storeResponse size is 0 ,display no record found message on screen.
                    if (storeResponse.length == 0) {
                        component.set("v.Message", true);
                    } else {
                        component.set("v.Message", false);
                    }
                   
                   
                   
                    // set searchResult list with return value from server.
                    component.set("v.AttendeesList", storeResponse);
                   
                   
                }else if (state === "INCOMPLETE") {
                    alert('Response is Incompleted');
                }else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            alert("Error message: " +
                                  errors[0].message);
                        }
                    } else {
                        alert("Unknown error");
                    }
                }
            });
            $A.enqueueAction(action);
            setTimeout(function() {
                //alert('Searched for "' + queryTerm + '"!');
                component.set('v.issearching', false);
            }, 1000);
           
        }
    }
    
    
})