({
	    
    helperToastMessage : function(strmessage,strtype) {
		var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error Message',
                message:strmessage,
                messageTemplate: 'Item already added.',
                duration:' 1000',
                key: 'info_alt',
                type: strtype,
                mode: 'pester'
            });
            toastEvent.fire();
	}
     
})