({
 
updateItem : function(component, item, callback){
 
var action = component.get("c.saveIte");
 
action.setParams({"item" : item});
  
if (callback){
 
action.setCallback(this, callback);
 
}
 
$A.enqueueAction(action);
 
}
 
})