({
 
newItemEvent : function(component, event, helper){
 
helper.updateItem(component, item, callback);
 
}
 
})