({
	handleSearchEventClicking: function(component,mapName,listForDisplay,controllerMethod,rId,timeId){
    timeId=null;
     var action = component.get(controllerMethod);
    action.setParams({
         inputText : component.find(rId).get("v.value")
    });        


    action.setCallback(this,function(result){
        var state = result.getState();
        console.log("state",state);
        if(component.isValid() && state === "SUCCESS"){
            var resultArray = result.getReturnValue();
            component.set(mapName,resultArray);
            var generalArray = [];
            for(var key in resultArray){
                generalArray.push({value:resultArray[key], key:key})
            }


            component.set(listForDisplay, generalArray);

        }else if(state =="ERROR"){
            console.log("Error",result.getError());
        }
    });
    $A.enqueueAction(action);
}
})