({
    
    
   enableButtonOnChange: function (component, event)
   {
       
        var start = component.get("v.startDate");
        var end = component.get("v.endDate");
       
  
 	if(start != null  && end != null)
     {
         component.set("v.isDisabled",false);    
     }
 	 else
     {
   		component.set("v.isDisabled",true);
     }
  },
    
  
  
})