({
     //Account DataTable with Select Rows Option      
 fetchAccounts : function(component, event) {
  
        var action = component.get("c.fetchAccts");
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            
            if (state === "SUCCESS") {
                
                var records = response.getReturnValue();
                records.forEach(function(record) {
                    
                    record.linkName = '/' + record.Id;
                    record.CheckBool = false;
                    
                });   
                
                component.set("v.acctList", records);
                
            }            
            
        });
        
        $A.enqueueAction(action);
        
 },
    
    
     fetchAccounts_2 : function(component, event, offSetCount) {
  
        var action = component.get("c.fetchAccts");
        action.setParams({
            
            "intOffSet" : offSetCount
            
        });
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/'+record.Id;
                });
                var currentData = component.get('v.accountList');                
                component.set("v.accountList", currentData.concat(records));
            }
         event.getSource().set("v.isLoading", false);
            
        });
        
        $A.enqueueAction(action);
        
 }
    
})