({
    //Basic Radio CheckBox Group 
    handleChange: function (component, event) {
        alert1(event.getParam('value'));
    }
});