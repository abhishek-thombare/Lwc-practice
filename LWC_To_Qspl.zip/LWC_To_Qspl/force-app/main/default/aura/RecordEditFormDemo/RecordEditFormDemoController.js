({
	handleSubmit : function(component, event, helper) {
		console.log("handle submit event fired");
	}
})