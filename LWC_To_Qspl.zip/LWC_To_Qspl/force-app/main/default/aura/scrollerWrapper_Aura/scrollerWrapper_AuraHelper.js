({
    canScroll : function (el) {
        var canScrollY = el.scrollHeight > el.offsetHeight;
        var canScrollX = el.scrollWidth > el.offsetWidth;
        return canScrollY || canScrollX;
    },
    isElementThatScrollAlways : function (target) {
        var isInputRange = target.tagName === 'INPUT' && target.type === 'range';
        return isInputRange;
    },
    isElementWithNativeScroll : function (target) {
        var isTextarea = target.tagName === 'TEXTAREA';
        return isTextarea;
    },
    isAtTop : function (el) {
        return el.scrollTop === 0;
    },
    isAtBottom : function (el) {
        return el.scrollHeight - el.scrollTop === el.offsetHeight
                || el.scrollHeight - el.scrollTop === el.clientHeight;
    },
    skipUIScroller : function (event) {
        event.cancelScrolling = true;
        event.preventBounce = false;
    },
    enableUIScroller : function (event) {
        event.cancelScrolling = false;
        event.preventBounce = true;
    },
    getWrapperElement : function(cmp) {
        return cmp.find("scrollerWrapper").getElement();
    },
    handleScrollTo : function (cmp, event) {
        var params = event.getParam('arguments'),
            dest    = params.destination,
            x       = params.xcoord || 0,
            y       = params.ycoord || 0;

        if (dest) {            
            var wrapper = this.getWrapperElement(cmp);

            dest = dest.toLowerCase();
            if (dest === 'custom') {
                wrapper.scrollTop  = Math.abs(y);
                wrapper.scrollLeft =  Math.abs(x);
            } else if (dest === 'top') {
                wrapper.scrollTop = 0;
            } else if (dest === 'left') {
                wrapper.scrollLeft = 0;
            } else if (dest === 'bottom') {
                wrapper.scrollTop = wrapper.scrollHeight - wrapper.clientHeight;
            } else if (dest === 'right') {
                wrapper.scrollLeft = wrapper.scrollWidth - wrapper.clientWidth;
            }
        }
    }

})