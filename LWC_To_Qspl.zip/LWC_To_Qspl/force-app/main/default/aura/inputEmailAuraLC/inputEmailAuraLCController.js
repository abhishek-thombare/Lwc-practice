({
    setOutput : function(component, event, helper) {
    	var cmpMsg = component.find("msg");
    	$A.util.removeClass(cmpMsg, 'hide');
    	
        var email = component.find("email").get("v.value"); 
        var oEmail = component.find("oEmail");
        oEmail.set("v.value", email);
        
    }
})