({

    onClick: function (cmp, event) {
        if (cmp.isValid()) {
          // $A.util.squash(event, true);
            cmp.getConcreteComponent().select();
        }
    }
})