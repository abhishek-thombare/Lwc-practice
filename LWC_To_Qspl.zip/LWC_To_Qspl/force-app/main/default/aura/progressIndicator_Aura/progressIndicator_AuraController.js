({
    //Path Type Iterator Indicator
    init: function (cmp) {
        cmp.set('v.steps', [
            { label: 'Contacted', value: 'step-1' },
            { label: 'Open', value: 'step-2' },
            { label: 'Unqualified', value: 'step-3' },
            { label: 'Nurturing', value: 'step-4' },
            { label: 'Closed', value: 'step-5' }
        ]);
    },
    
    //Path Type with if condition
    toggleStep4: function (cmp) {
        cmp.set('v.showStep4', !cmp.get('v.showStep4'));
    }
    
    
});