({
    onGroup: function(cmp, evt) {
        var selected = evt.getSource().get("v.text");
       // alert(selected);
    }

})