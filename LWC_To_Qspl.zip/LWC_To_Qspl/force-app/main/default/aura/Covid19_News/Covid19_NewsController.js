({
	doInit : function(component, event, helper) {
		helper.fetchNewsData(component, event, helper);
	}
})