({
    fetchNewsData : function(component, event, helper) {
        var action=component.get("c.fetchNews");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = JSON.parse(JSON.stringify(response.getReturnValue()));
                component.set('v.newsData',result.articles);
                console.log('Articles = '+JSON.stringify(result.articles));
                //console.log(' Result : ' +JSON.stringify(result.articles[0].title));
            }
        });
        $A.enqueueAction(action);
    }
})