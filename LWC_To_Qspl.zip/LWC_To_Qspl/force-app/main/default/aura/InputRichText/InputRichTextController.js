({
    init: function(cmp) {
        cmp.set('v.myVal', '<p><script>alert(this)</script></p><p>hi!</p>');
    }
});