({
    doInit : function(component, event, helper) {
    component.set('v.routeInput', {recordId: component.get('v.recordId')});
    },

    onClick : function(component, event, helper) {
           var navEvt = $A.get("e.force:navigateToSObject");
           navEvt.setParams({
             "recordId": component.get('v.recordId')
           });
           navEvt.fire();
   }
})