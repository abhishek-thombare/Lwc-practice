({
    init: function (cmp) {
        var items = [{
            "label": "Western Sales Director",
            "name": "1",
            "metatext": "Jane Dough",
            "expanded": true,
            "items": [{
                "label": "Western Sales Manager",
                "name": "2",
                "metatext": "John Doe",
                "expanded": true,
                "items" :[{
                    "label": "CA Sales Rep",
                    "name": "3",
                    "metatext": "Buck Rogers",
                    "expanded": true,
                    "items" :[]
                }, {
                    "label": "OR Sales Rep",
                    "name": "4",
                    "metatext": "Flash Gordon",
                    "expanded": true,
                    "items" :[]
                }]
            }]
        }, {
            "label": "Eastern Sales Director",
            "name": "5",
            "metatext": "Emma Frost",
            "expanded": false,
            "items": [{
                "label": "Easter Sales Manager",
                "name": "6",
                "expanded": true,
                "items" :[{
                    "label": "NY Sales Rep",
                    "name": "7",
                    "metatext": "John Crichton",
                    "expanded": true,
                    "items" :[]
                }, {
                    "label": "MA Sales Rep",
                    "name": "8",
                    "expanded": true,
                    "items" :[]
                }]
            }]
        }, {
            "label": "International Sales Director",
            "name": "9",
            "metatext": "Aeryn Sun",
            "expanded": true,
            "items": [{
                "label": "Asia Sales Manager",
                "name": "10",
                "expanded": true,
                "items" :[{
                    "label": "Sales Rep1",
                    "name": "11",
                    "expanded": true,
                    "items" :[]
                }, {
                    "label": "Sales Rep2",
                    "name": "12",
                    "expanded": true,
                    "items" :[]
                }]
            }, {
                "label": "Europe Sales Manager",
                "name": "13",
                "expanded": false,
                "items" :[{
                    "label": "Sales Rep1",
                    "name": "14",
                    "expanded": true,
                    "items" :[]
                }, {
                    "label": "Sales Rep2",
                    "name": "15",
                    "expanded": true,
                    "items" :[]
                }]
            }]
        }];
        cmp.set('v.items', items);
    },
    
    handleSelect: function (cmp, event) {
        event.preventDefault();
        var mapping = { '1' : 'Western Sales Director', '2' : 'Western Sales Manager', '3' : 'CA Sales Rep',
            '4' : 'OR Sales Rep', '5' : 'Eastern Sales Director', '6' : 'Easter Sales Manager',
            '7' : 'NY Sales Rep', '8' : 'MA Sales Rep', '9' : 'International Sales Director', '10' : 'Asia Sales Manager', '11' : 'Sales Rep1', '12' : 'Sales Rep2','13' : 'Europe Sales Manager','14' : 'Sales Rep1', '15' : 'Sales Rep2'};
        cmp.set('v.selected', mapping[event.getParam('name')]);
    }
 
    
});