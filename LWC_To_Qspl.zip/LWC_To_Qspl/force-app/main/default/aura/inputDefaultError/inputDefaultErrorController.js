({
    checkInput : function(cmp) {
    	var colorCmp = cmp.find("color");
        var myColor = colorCmp.get("v.value");

        var myOutput = cmp.find("outColor");
        var greet = "You entered: " + myColor;
        myOutput.set("v.value", greet);

        if (!myColor) {
            colorCmp.set("v.errors", [{message:"Enter some text"}]);
        }
        else {
            colorCmp.set("v.errors", null);
        }
    },
    
    checkerror : function(cmp) {
    	var colorCmp = cmp.find("color1");
        var myColor = colorCmp.get("v.value");

        var myOutput = cmp.find("outText");
        var greet = "You entered: " + myColor;
        myOutput.set("v.value", greet);

        if (!myColor) {
            colorCmp.set("v.errors", [{message:"Enter some text"}]);
           }
           else {
           	 colorCmp.set("v.errors", null);
           }
    },
    
    
    //Hide-Show Event 
    hide : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'none';
     	setTimeout(function(){ elements[0].style.display = 'block';},9000); 
    },
    
    show : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'block';
    },
    
    /*
    changedisabled: function(component,event,helper){
    var vbtn = event.getSource();
    vbtn.set('v.disabled',false);
    }
   */
    
})