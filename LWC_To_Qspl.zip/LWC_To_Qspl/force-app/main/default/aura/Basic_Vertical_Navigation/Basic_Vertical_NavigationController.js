/*
 //Vertical Navigation From Data Map
({
    init1: function (component) {
        var sections = [
          {
            label: "Reports",
            items: [
              {
                label: "Recent",
                name: "default_recent",
                icon: "utility:clock"
              },
              {
                label: "Created by Me",
                name: "default_created"
              },
              {
                label: "Public Reports",
                name: "default_public"
              },
              {
                label: "My P1 Bugs",
                name: "custom_p1bugs"
              }
            ]
          },

          {
            label: "Dashboards",
            items: [
              {
                label: "Favorites",
                name: "default_favorites",
                icon: "utility:favorite"
              },
              {
                label: "Most Popular",
                name: "custom_mostpopular"
              },
              {
                label: "Summer Release Metrics",
                name: "custom_newreleaseadoption"
              }
            ]
          }
        ];

        component.set('v.initiallySelected', 'default_recent');
        component.set('v.navigationData', sections);
    }
});
*/

//Asynchronous Validation on Vertical Navigation:
({
    init: function (component) {
        component.set('v.hasBeenEdited', false);
        component.set('v.selectedItem', 'report_1');
    },

    handleClick: function(component) {
        component.set('v.hasBeenEdited', true);
    },

    handleBeforeSelect: function(component, event) {
        if (component.get('v.hasBeenEdited')) {
            // Prevent the onselect handler from running
            event.preventDefault();

            component.set('v.asyncValidation', true);

            setTimeout($A.getCallback(function () {
                component.set('v.hasBeenEdited', false);
                component.set('v.selectedItem', event.getParam('name'));
                component.set('v.asyncValidation', false);
            }), 2000);
        }
    }
});