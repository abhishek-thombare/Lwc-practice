({
	 handleSpeech: function(component, event, helper) {
        if('speechSynthesis' in window)
        {
            var text=component.find("speechText").get("v.value");
       		var speech = new window.SpeechSynthesisUtterance(text);
            speech.lang = 'en-US';
            window.speechSynthesis.speak(speech);
        }
        else
        {
            alert('speechSynthesis not supported');
        }
    }
})