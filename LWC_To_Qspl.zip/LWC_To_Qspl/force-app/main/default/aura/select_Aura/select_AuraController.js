({
    onChange: function (cmp, evt, helper) {
    //    alert(cmp.find('select').get('v.value') + ' pie is good.');
    },
    

  
    init: function (cmp, event, helper) {
        helper.simulateServerRequest(
            $A.getCallback(function handleServerResponse(serverResponse) {
                cmp.set('v.options', serverResponse.colors);
                cmp.set('v.selectedValue', serverResponse.selectedColorId);
            })
        );
     
     
       setTimeout(function(){

           
        var xyz=document.getElementById("xyz");
        var abc=document.createElement("select");
        
        abc.setAttribute('class',"slds-select")
        abc.setAttribute('name',"select number")
        abc.setAttribute('label',"Choose one option")
        abc.setAttribute('required',"true")
        abc.setAttribute('onchange',"{!c.DisableChange}")
        abc.innerHTML=`
                    <option value="">choose one...</option>
                    <option value="1">one</option>
                    <option value="2">two</option>
                    <option value="3">three</option>
                    `                  
        xyz.appendChild(abc);
        
         
         
         },5000);
        
    },
    
    //Hide-Show Event 

    hide : function(component,event,helper){
        var element=document.getElementById("xyz");
        element.innerHTML="";
        setTimeout(function(){ elements[0].style.display = 'block';},9000); 
 
        
        
        //var elements = document.getElementsByClassName("myTest");
        //elements[0].style.display = 'none';
        //elements[0].remove = 'none';
        //elements[0].parentNode.remove(elements[0]);
       // elements[0].parentNode.remove(elements[0]);
        // setTimeout(function(){ elements[0].style.display = 'block';},9000); 
    },
    
    show : function(component,event,helper){
    	var xyz=document.getElementById("xyz");
        var abc=document.createElement("select");
        
        abc.setAttribute('class',"slds-select")
        abc.setAttribute('name',"select number")
        abc.setAttribute('label',"Choose one option")
        abc.setAttribute('required',"true")
        abc.setAttribute('onchange',"{!c.DisableChange}")
        abc.innerHTML=`
                    <option value="">choose one...</option>
                    <option value="1">one</option>
                    <option value="2">two</option>
                    <option value="3">three</option>
                    `                  
        xyz.appendChild(abc);
        
    	/*element.innerHTML=
		<lightning:select name="select number" label="Choose one option" required="true" onchange="{!c.DisableChange}">
    		<option value="">choose one...</option>
       		<option value="1">one</option>
    		<option value="2">two</option>
    		<option value="3">three</option>
			</lightning:select><br/>
			*/
        
        
        //var elements = document.getElementsByClassName("myTest");
        //elements[0].style.display = 'block';
    },

    
    DisableChange: function(component,event,helper){
        let picklist = event.getSource();
        picklist.set('v.disabled',true);
        setTimeout(function(){picklist.set('v.disabled',false);},5000);    
      }
 
})