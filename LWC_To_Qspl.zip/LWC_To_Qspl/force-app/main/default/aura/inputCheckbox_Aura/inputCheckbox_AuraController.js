({
	myAction : function(component, event, helper) {
		
	},
    onCheck: function(cmp, evt) {
       	// alert("Clicked");
		 var checkCmp = cmp.find("checkbox");
       	// alert(checkCmp.get("v.value"));
//		 resultCmp = cmp.find("checkResult");
		// resultCmp.set("v.value", ""+checkCmp.get("v.value"));

	 },
    //toggle changes
    selectChange : function(cmp, event, helper) {
        var checkCmp = cmp.find("chkbox");
        cmp.set("v.toggleValue" ,  checkCmp.get("v.value"));
    }
})