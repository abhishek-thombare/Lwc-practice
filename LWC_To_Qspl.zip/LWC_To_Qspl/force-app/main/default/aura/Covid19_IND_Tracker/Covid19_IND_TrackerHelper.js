({
    COLUMNS:[
        {label: 'STATE/UT', fieldName: 'STATEUT', type: 'text'},
        {label: 'CNFMD', fieldName: 'CNFMD_CASE',
         type: 'number',
         sortable: true,
         cellAttributes: { alignment: 'left' }},
        {label: 'ACTIVE', fieldName: 'ACTIVE_CASE', type: 'text'},
        {label: 'RCVRD', fieldName: 'RCVRD_CASE', type: 'text'},
        {label: 'DECEASED', fieldName: 'DEATH', type: 'text'}
        
    ],
    DATA: [],
    fetchData : function(component,event,helper) {
        var action = component.get("c.fecthCovid19Data");
        
        action.setCallback(this,function(response){
            var state1 = response.getState();
            
            if(state1 =='SUCCESS'){
                var result = JSON.parse(JSON.stringify(response.getReturnValue()));
                component.set('v.columns', [
                    {label: 'STATE/UT', fieldName: 'STATEUT', type: 'text',sortable: true},
                    {label: 'CNFMD', fieldName: 'CNFMD_CASE',
                     type: 'number',cellAttributes: { alignment: 'left' }},
                    {label: 'ACTIVE', fieldName: 'ACTIVE_CASE', type: 'text'},
                    {label: 'RCVRD', fieldName: 'RCVRD_CASE', type: 'text'},
                    {label: 'DECEASED', fieldName: 'DEATH', type: 'text'}
                    
                ]);
                component.set('v.confirmed',result.statewise[0].confirmed);
                component.set('v.active',result.statewise[0].active);
                component.set('v.recovered',result.statewise[0].recovered);
                component.set('v.deaths',result.statewise[0].deaths);
                var dataArry = new Array();
                for(var i=0; i< result.statewise.length; i++){
                    //alert(result.statewise[i].state);
                    console.log('count >> '+i +' '+JSON.stringify(result.statewise[i].state));
                    var fetchData = {
                        id : i,
                        STATEUT: result.statewise[i].state,
                        CNFMD_CASE : result.statewise[i].confirmed,
                        ACTIVE_CASE : result.statewise[i].active,
                        RCVRD_CASE : result.statewise[i].recovered,
                        DEATH : result.statewise[i].deaths
                        
                    };
                    
                    
                    dataArry.push(fetchData);
                    
                }
                dataArry.shift();
                console.log('data Array = '+dataArry);
                component.set('v.data',dataArry);
                this.DATA = dataArry;
                //component.set('v.lastUpdated',result.key_values[0].lastupdatedtime);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    
    setColumns: function(component) {
        component.set('v.columns', this.COLUMNS);
    },
    
    setData: function(component) {
        component.set('v.data', this.DATA);
    },
    
    // Used to sort the 'Age' column
    sortBy: function(field, reverse, primer) {
        var key = primer
        ? function(x) {
            return primer(x[field]);
        }
        : function(x) {
            return x[field];
        };
        
        return function(a, b) {
            a = key(a);
            b = key(b);
            return reverse * ((a > b) - (b > a));
        };
    },
    
    handleSort: function(component, event) {
        var sortedBy = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        //alert(component.get('v.data'));
        //var DATA = component.get('v.data');
        var cloneData = this.DATA.slice(0);
        cloneData.sort((this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1)));
        
        component.set('v.data', cloneData);
        component.set('v.sortDirection', sortDirection);
        component.set('v.sortedBy', sortedBy);
    }
})