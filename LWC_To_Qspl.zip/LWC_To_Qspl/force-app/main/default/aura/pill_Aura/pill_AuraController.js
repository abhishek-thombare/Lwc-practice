({
    //Basic Pill
    handleRemove: function (cmp, event) {
        alert('Remove button was clicked!');
    },
    handleRemoveOnly: function (cmp, event) {
        event.preventDefault();
        alert('Remove button was clicked!');
    },
    handleClick: function () {
        alert('The pill was clicked!');
    },
    
    
    //custom Pill
    
      search : function(component, event, helper) {
        var thisObjVal = event.getSource().get('v.value');
        var thisObjValLnth = thisObjVal.length;
        var srchLookupVal = component.find('srchLookupVal');
        //alert(thisObjVal + thisObjValLnth);        
        if(thisObjVal && thisObjValLnth>2){
            var action = component.get("c.searchUsersName"); 
            action.setParams({'key':thisObjVal});
            action.setCallback(this, function(response){
                var state =  response.getState();
                if(state == 'SUCCESS'){
                   var result = response.getReturnValue();                     
                    if(result && result.length>0){
                        component.set('v.searchResults',result);
                        component.set('v.pillSearch',true);
                       //$A.util.addClass(srchLookupVal,'slds-show'); 
                        
                    }else{
                        component.set('v.searchResults',"");
                        $A.util.removeClass(srchLookupVal,'slds-show');
                    }
                                   
                    
                }
            });
            $A.enqueueAction(action);
            
        }
        
    },
    
    searchSelect:function(component, event, helper){
        var thisObjVal = event.target.innerText;
        var srchLookupVal = component.find('srchLookupVal');
        var recipients = component.get("v.recipients");       
        recipients.push({
            Name: thisObjVal
        }); 
       
         var recipientsNoDupes = [];        
        for(var i = 0; i < recipients.length; i++) {
            recipientsNoDupes.push(recipients[i]);
        }
        component.set("v.recipients", recipientsNoDupes);   
         component.set('v.pillSearch',false);
       // $A.util.removeClass(srchLookupVal,'slds-show');
        component.set('v.searchLookup','');
    },
    
    removeRecipient:function(component, event, helper){
        var eventDataSet = event.target.dataset.index;
        //alert('eventDataSet ' + eventDataSet);
        var recipients = component.get('v.recipients');
        recipients.splice(Number(eventDataSet),1);
        component.set("v.recipients", recipients);
    },
    
    addToRecipients:function(component, event, helper){
         var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
         var recipients = component.get("v.recipients");  
         var searchLookup = component.get("v.searchLookup");
        
        if(searchLookup){
            if(searchLookup.match(regExpEmailformat)){
                document.getElementById("emailVerify").classList.add("slds-hide");
                var recipients = component.get("v.recipients");
                recipients.push({                    
                    Name: searchLookup,
                    Email: searchLookup,
                    Id: ''
                });
                var recipientsNoDupes = [];
               
                for(var i = 0; i < recipients.length; i++) {
                    recipientsNoDupes.push(recipients[i]);
                }
                //alert('recipientsNoDupes ' + recipientsNoDupes);
                component.set("v.recipients", recipientsNoDupes);
                //alert('recipients ' + JSON.stringify(recipients));
                component.set("v.searchLookup","");
            }
             else{
                document.getElementById("emailVerify").classList.remove("slds-hide");
            }
        }
        
    },  
    
    changeType:function(component, event, helper){
        var thisObjId = document.getElementById('recipientTypeSelectBox').value;
        var addItemBtn = component.find('addItemBtn');
        if(thisObjId == 'Email'){
            $A.util.removeClass(addItemBtn,'slds-hide');
        }else{
            $A.util.addClass(addItemBtn,'slds-hide');
        }
    },   
    
    
    
    
    
    
    
    
    
});