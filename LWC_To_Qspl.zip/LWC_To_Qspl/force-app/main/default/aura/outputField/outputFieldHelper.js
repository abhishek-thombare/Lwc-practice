({
   showEditableDiv : function(cmp) {
     var elementEdit = document.getElementById('editableDiv');
     elementEdit.style.display = 'block';
     var elementView = document.getElementById('viewableDiv');
     elementView.style.display = 'none';
   },
   
   hideEditableDiv : function(cmp) {
     var elementEdit= document.getElementById('editableDiv');
     elementEdit.style.display = 'none';
     var elementView = document.getElementById('viewableDiv');
     elementView.style.display = 'block';
   }
})