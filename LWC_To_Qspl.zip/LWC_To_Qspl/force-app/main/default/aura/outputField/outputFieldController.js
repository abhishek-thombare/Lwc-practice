({
   editAccount:function(cmp, event, helper){
     helper.showEditableDiv(cmp);
   },

   handleAccountSaved: function(cmp, event, helper) {
     helper.hideEditableDiv(cmp);
   }
})