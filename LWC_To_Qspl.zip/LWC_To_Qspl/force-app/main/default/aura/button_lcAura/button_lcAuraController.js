({
	//Basic Buttons
    handleClick : function (cmp, event, helper) {
        alert("You clicked: " + event.getSource().get("v.label"));
    },

    handleClick1 : function (cmp, event, helper) {
        alert('Clicked !!');
    },

    // ----------------------------------------------------------
	//Basic Icon-Only Button
	handleClick2 : function (cmp, event) {
        alert("Success");
    },
   
    // ----------------------------------------------------------
    //Stateful Button Icons
    handleLikeButtonClick : function (cmp) {
        alert("You liked !!");
        cmp.set('v.liked', !cmp.get('v.liked'));
         
    },
    handleAnswerButtonClick: function (cmp) {
        alert("You Answered !!");
        cmp.set('v.answered', !cmp.get('v.answered'));
        
    },
    
     // ----------------------------------------------------------
    //Button Menus with Subheaders and Dividers
    
    handleSelect: function (cmp, event, helper) {
        // This will contain the string of the "value" attribute of the selected
        // lightning:menuItem
        var selectedMenuItemValue = event.getParam("value");
        alert("Menu item selected with value: " + selectedMenuItemValue);
    },
    
    // ----------------------------------------------------------
    //Checked Menu Items (All Menu Items can be Checked at a Time)
     handleSelect1: function (cmp, event) {
        // This will contain the index (position) of the selected lightning:menuItem
        var selectedMenuItemValue = event.getParam("value");
        // Find all menu items
        var menuItems = cmp.find("menuItems");
        // Get the selected menu item
        var menuItem = menuItems.find(function(menuItem) {
            return menuItem.get("v.value") === selectedMenuItemValue;
        });
        // Toggle the existing checked value, if it was true, it will be set to false, and vice-versa
        menuItem.set("v.checked", !menuItem.get("v.checked"));
    },
    
    
     // ----------------------------------------------------------
    //Checked Menu Items with Icons (One Menu Item Checked at a Time)
   
   handleSelect2: function (cmp, event) {
        // This will contain the index (position) of the selected lightning:menuItem
        var selectedMenuItemValue = event.getParam("value");

        // Find all menu items
        var menuItems = cmp.find("menuItems");
        menuItems.forEach(function (menuItem) {
            // For each menu item, if it was checked, un-check it. This ensures that only one
            // menu item is checked at a time
            if (menuItem.get("v.checked")) {
                menuItem.set("v.checked", false);
            }
            // Check the selected menu item
            if (menuItem.get("v.value") === selectedMenuItemValue) {
                menuItem.set("v.checked", true);
            }
        });
    },
    
   // ----------------------------------------------------------
   //Basic Stateful Buttons
   handleClick3 : function (cmp, event, helper) {
        var buttonstate = cmp.get('v.buttonstate');
        cmp.set('v.buttonstate', !buttonstate);
    },
    
    
   handleClick4 : function (cmp, event, helper) {
        var buttonstate1 = cmp.get('v.buttonstate1');
        cmp.set('v.buttonstate1', !buttonstate1);
    }
    
    
});