({
	onRadio: function(cmp, evt) {
		 var selected = evt.getSource().get("v.label");
		
	 },

	 onGroup: function(cmp, evt) {
		 var selected = evt.getSource().get("v.label");
	
	 }
})