({
    displaySection1 : function(component, event, helper) {
        component.set("v.displayedSection","section1");
        var section1InputValue = component.find("sec1value");
		section1InputValue.set('v.disabled',true);
    	setTimeout(function(){section1InputValue.set('v.disabled',false);},5000);   
       
        //console.log('***section1InputValue: '+section1InputValue);
        //var section2InputValue = component.find("sec2value");
        //console.log('***section2InputValue: '+section2InputValue);
    },
    
 
    
    
    /*
    displaySection2 : function(component, event, helper) {
        component.set("v.displayedSection","section2");
        var section1InputValue = component.find("sec1value");
        console.log('***section1InputValue: '+section1InputValue);
        var section2InputValue = component.find("sec2value");
        console.log('***section2InputValue: '+section2InputValue);
    },
    */
    
    //Hide-Show Event 
    hide : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'none';
  		
        //Remove from DOM
  		//elements[0].remove();
        
        //Create & call element again to DOM
      	// var para = document.createElement("div");
  		 //document.getElementsByClassName("myTest").appendChild(document.getElementsByClassName("test2"));
        
        
        
   		setTimeout(function(){
            		elements[0].style.display = 'block';
      			  },9000); 
    },
    
    show : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'block';
    },
    
    DisableChange: function(component,event,helper){
        let picklist = event.getSource();
    	picklist.set('v.disabled',true);
    	setTimeout(function(){picklist.set('v.disabled',false);},5000);    
      }

     
})