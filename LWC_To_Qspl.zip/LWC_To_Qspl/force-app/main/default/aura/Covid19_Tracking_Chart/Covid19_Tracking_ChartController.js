({
	doInit : function(component, event, helper) {
		helper.CreateChart(component);	
	}
})