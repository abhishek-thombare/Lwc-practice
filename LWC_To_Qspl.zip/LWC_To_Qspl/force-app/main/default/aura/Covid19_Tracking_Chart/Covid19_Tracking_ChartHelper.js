({
    CreateChart : function(component) {
        var chartType= 'bar'; 
        var action=component.get("c.fecthCovid19Data");
        action.setCallback(this,function(response){
            var state=response.getState();
            if(state=='SUCCESS'){
                var result = JSON.parse(JSON.stringify(response.getReturnValue()));
                console.log('result : ' +JSON.stringify( result));
                var data = [];
                var Label= [];
                var data1 = [];
                var Label1= [];
                for(var i=0; i< result.statewise.length; i++){
                    var tLabel = result.statewise[i].state;
                    Label.push(tLabel);
                    
                    var tValue = result.statewise[i].confirmed;
                    data.push(tValue);
                    
                    var tLabel = result.statewise[i].state;
                    Label1.push(tLabel);
                    
                    var tValue = result.statewise[i].deaths;
                    data1.push(tValue);
                    
                }
                Label.shift();
                data.shift();
                console.log('Label : '+Label);
                console.log('data : '+data);
                //Create chart1
                var el=component.find('myChart').getElement();
                var ctx=el.getContext('2d');
                if(window.bar!=undefined){
                    window.bar.destroy();
                }
                var background_color=new Array();
                for(var i=0 ; i<100 ; i++){
                    var w,x,y,z;
                    w = parseInt(Math.random()*255);
                    x = parseInt(Math.random()*255);
                    y = parseInt(Math.random()*255);
                    z = Math.random();
                    background_color.push('rgba('+w+','+x+','+y+','+z+')');  
                }
                window.bar = new Chart(ctx, {
                    type: chartType,
                    data: {
                        labels: Label,
                        datasets: [
                            {
                                label: "CONFIRMED CASE",
                                fillColor: background_color,
                                backgroundColor: background_color,
                                strokeColor: "rgba(220,220,220,1)",                
                                data: data
                            }
                        ]
                    },
                    options: {
                        hover: {
                            mode: "none"
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero:true
                                }
                            }]
                        }
                    }
                });
            }
            
        });
        $A.enqueueAction(action);
    },
})