({
    saveAccount : function(component, event, helper) {
        var objAccount = component.get("v.objAcc");
        var action = component.get('c.insertAccount');
        action.setParams({
            objAcc:objAccount
        });
        action.setCallback(this, function(response) {
            window.setTimeout(
	    $A.getCallback(function() {
        cmp.set("v.visible", true);
   		 }), 5000
		);
            
            
            var state = response.getState();
            if(state === "SUCCESS") {
                component.find('notifLib').showToast({
                    "variant": "success",
                    "title": objAccount.Name,
                    "message": "The record has created successfully."
                });
                component.set('v.isHide', true);
                setTimeout(function(){component.set('v.isHide', false);},10000)
            }
        });
        $A.enqueueAction(action);
    },
    

    
})