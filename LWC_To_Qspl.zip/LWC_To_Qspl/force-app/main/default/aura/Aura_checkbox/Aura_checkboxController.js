({
    handleChange: function (component, event) {
        //alert(event.getParam('value'));
    }
});