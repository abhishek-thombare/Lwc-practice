({
	disableFields : function(component, event, helper) {
        var val = component.find("accountName").get("v.value");
        if(val != null){
             component.set('v.hide' , "false");
              setTimeout(function(){component.set('v.hide' , "true");},10000)
        }
	},
    
   //CheckBox Click Hide inputFields
   onCheck : function(component, event, helper){
	   component.set("v.loaded" , false);
   	   component.set("v.disabled", false);
   },
   onUnCheck :function(component, event, helper){
       var val=component.set("v.loaded" , true);
   },
    
    
    //Checkbox
    Showhide : function(component, event, helper) {
        let checkBoxState = event.getSource().get('v.value');
        console.log(event.getSource().get('v.value'));
        component.find("disableenable").set("v.disabled", !checkBoxState);
    },
    
    //Change Label On Click
  	docheckClick : function(component, event, helper) {
            var label = event.getSource().get("v.label");
            if(label == 'Select All') {
                event.getSource().set("v.label","Deselect All")
            } else {
                event.getSource().set("v.label","Select All")
            }
	 },
    
    
    //Change Input Field Label
    inputClick : function(component, event, helper) {
            var label = event.getSource().get("v.label");
            if(label == 'FullName') {
                event.getSource().set("v.label","Writing FullName")
            } else {
                event.getSource().set("v.label","FullName")
            }
	 }
    
})