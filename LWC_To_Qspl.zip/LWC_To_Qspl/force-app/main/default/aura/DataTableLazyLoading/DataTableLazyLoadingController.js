({
    init: function (cmp, event, helper) {
        console.log( cmp.get("v.data").length );
        helper.initData(cmp, event, cmp.get("v.data").length);        
    },
    
    updateSelectedRow: function (cmp, event) {
        var selectedRows = event.getParam('selectedRows');
        cmp.set('v.selectedRowsCount', selectedRows.length);
        cmp.set('v.selectedData', selectedRows);
        console.log( cmp.get('v.selectedData') );
    },
    
    resetRows: function (cmp, event, helper) {
        cmp.set('v.data', []);
        helper.initData(cmp, event, cmp.get("v.data").length);
    },
    
    loadMoreData: function (cmp, event, helper) {
        var rowsToLoad = cmp.get('v.rowsToLoad');

        event.getSource().set("v.isLoading", true);
        cmp.set('v.loadMoreStatus', 'Loading');
        helper.fetchData(cmp, event, cmp.get("v.data").length);
    },
    
    updateColumnSorting: function (cmp, event, helper) {
        
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        
        // assign the latest attribute with the sorted column fieldName and sorted direction
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        cmp.set('v.data', []);
        event.getSource().set("v.isLoading", true);
        cmp.set('v.loadMoreStatus', 'Loading');
        helper.initData(cmp, event, cmp.get("v.data").length);
    },
    
    handleRowAction: function (cmp, event, helper) {
        
        var action = event.getParam('action');
        var row = event.getParam('row');
        
        switch (action.name) {
            case 'Edit':
                helper.editRecord(cmp, row);
                break;
            case 'View':
                helper.viewRecord(cmp, row);
                break;
            case 'Delete':
                helper.deleteRecord(cmp, row);
                break;
            default:
                helper.viewRecord(cmp,row);
                break;
        }
    },
    
    handleSaveEdition: function (cmp, event, helper) {
        var draftValues = event.getParam('draftValues');
        var data =  cmp.get('v.data');
        helper.saveRecords(cmp, event, helper, data, draftValues);
    }, 
})