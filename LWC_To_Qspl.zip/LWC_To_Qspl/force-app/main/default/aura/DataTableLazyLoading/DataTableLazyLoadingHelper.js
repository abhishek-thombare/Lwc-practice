({
    
    initData: function (cmp,  event, numberOfRecords) {
       
         var action = cmp.get("c.initRecords");
         action.setParams({
             ObjectName : cmp.get("v.objectName"),
             fieldNamesStr : cmp.get("v.fieldsString"),
             Orderby : cmp.get("v.sortedBy"),
             OrderDir : cmp.get("v.sortedDirection"),
             inlineEdit: cmp.get("v.inlineEdit"),
             enableColAction: cmp.get("v.enableColAction")
         });
	    action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log(response.getReturnValue().ldwList);
                cmp.set("v.columns", response.getReturnValue().ldwList);
                cmp.set("v.data", response.getReturnValue().sobList);
                cmp.set("v.fieldsList", response.getReturnValue().fieldsList);
                cmp.set("v.totalNumberOfRows", response.getReturnValue().totalCount);
                cmp.set('v.loadMoreStatus', '');
                event.getSource().set("v.isLoading", false);
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    fetchData: function (cmp,  event, numberOfRecords) {
       
         //var dataPromise;
         var data = cmp.get("v.data");
         var dataSize = cmp.get("v.data").length;
         var lastId = data[dataSize - 1].Id;
         var action = cmp.get("c.getsObjectRecords");
         action.setParams({
         	ObjectName : cmp.get("v.objectName"),
            fieldNameSet : cmp.get("v.fieldsList"),
            LimitSize : 50,
            recId : lastId,
            Orderby : cmp.get("v.sortedBy"),
            OrderDir : cmp.set("v.sortedDirection")
         });
		 action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                if (cmp.get('v.data').length >= cmp.get('v.totalNumberOfRows')) {
                    cmp.set('v.enableInfiniteLoading', false);
                    cmp.set('v.loadMoreStatus', 'No more data to load');
                } else {
                    var currentData = cmp.get('v.data');
                    var newData = currentData.concat(response.getReturnValue());
                    cmp.set('v.data', newData);
                    cmp.set('v.loadMoreStatus', '');
                }
                event.getSource().set("v.isLoading", false);
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.data");
        var reverse = sortDirection !== 'asc';
        //sorts the rows based on the column header that's clicked
        data.sort(this.sortBy(fieldName, reverse))
        cmp.set("v.data", data);
    },
    
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        //checks if the two rows should switch places
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    
    editRecord: function (cmp, row) {
        var navService = cmp.find("navService");
    
        var pageReference = {
            type: 'standard__recordPage',
            attributes: {
                "recordId": row.Id,
                "objectApiName": cmp.get("v.objectName"),
                "actionName": "edit"
            }
        }
        navService.navigate(pageReference);
    },
    
    viewRecord : function(cmp, row) {
        var navService = cmp.find("navService");
    	console.log(row);
        var pageReference = {
            type: 'standard__recordPage',
            attributes: {
                "recordId": row.Id,
                "objectApiName": cmp.get("v.objectName"),
                "actionName": "view"
            }
        }
        navService.navigate(pageReference);
    }, 
    
    deleteRecord : function(cmp, row) {
        var action = cmp.get("c.deleteSObject");
        action.setParams({
            "sob":row
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = cmp.get('v.data');
                var rowIndex = rows.indexOf(row);
                rows.splice(rowIndex, 1);
                cmp.set('v.data', rows);
               /* var toastEvent = $A.get("e.force:showToast");
        		      toastEvent.setParams({
                        "title": "Success!",
                        "message": "Record deleted.",
                        "type": "success"
                    });
                toastEvent.fire();
                */
                cmp.find('notifLib').showNotice({
                    "variant": "info",
                    "header": "Success!",
                    "message": "Record deleted.",
                    closeCallback: function() {
                    }
                });

            }
            else if (state === "ERROR") {
                // handle error
                var errorMsg = '';
                var errors = response.getError();
				          if (errors) {
                    if (errors[0] && errors[0].message) {
						          errorMsg = errors[0].message;
					          }
                    if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                      errorMsg += errors[0].pageErrors[0].message;
                    }
                }
				
                cmp.find('notifLib').showNotice({
                    "variant": "error",
                    "header": "Something has gone wrong!",
                    "message": errorMsg,
                    closeCallback: function() {
                    }
                });
                /*
                var errors = response.getError();                       
                var toastEvent = $A.get("e.force:showToast");
        		    toastEvent.setParams({
                        "title": "error",
                        "message": errorMsg,
                        "type": "error"
                    });
                toastEvent.fire();*/
            }
        });
        $A.enqueueAction(action);
    },
    
    saveRecords : function(cmp, event, helper, data, draftValues) {
        var action = cmp.get("c.updateRecords");
        var draftValuesStr = JSON.stringify(draftValues);
        action.setParams({
            "sobList":data,
            "updateObjStr" : draftValuesStr,
            "objectName" : cmp.get("v.objectName")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set('v.errors', []);
                cmp.set('v.draftValues', []);                
				        helper.initData(cmp, event, 50);
            }
            else if (state === "ERROR") {
                // handle error
		var errorMsg = '';
                var errors = response.getError();
		if (errors) {
                    if (errors[0] && errors[0].message) {
			errorMsg = errors[0].message;
		    }
                    if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                      errorMsg += errors[0].pageErrors[0].message;
                    }
                }
				
                cmp.find('notifLib').showNotice({
                    "variant": "error",
                    "header": "Something has gone wrong!",
                    "message": errorMsg,
                    closeCallback: function() {
                    }
                });
                cmp.set('v.errors', errorMsg);
            }
        });
        $A.enqueueAction(action);
    }

  });