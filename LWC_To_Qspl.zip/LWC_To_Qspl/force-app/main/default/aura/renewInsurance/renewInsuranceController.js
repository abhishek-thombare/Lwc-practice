({
  doInit: function(component, event, helper) {
  var isExpired = component.get("v.record.isExpired__c");
        
  if (isExpired == true){
  component.set("v.showDetail",true);
//below code is use as speech synthesis which will accept the string and speak  
   if('speechSynthesis' in window)
    {
    var speech = new window.SpeechSynthesisUtterance('This Insurance is expired. Please renew insurance');
    speech.lang = 'en-US';
    window.speechSynthesis.speak(speech);   
     }           
    else
      {
    alert('speechSynthesis not supported');
       }
      }else if(isExpired == false){
//below code is use as speech synthesis which will accept the string and speak 
    if('speechSynthesis' in window)
    {
   var speech = new window.SpeechSynthesisUtterance('This Insurance is Live now');
    speech.lang = 'en-US';
    window.speechSynthesis.speak(speech);   
      }           
      else
      {
       alert('speechSynthesis not supported');
      }
    } 
  },
    
handleChange : function(component, event, helper) {
  var renewDate = component.get("v.renewDate");
  var recordId = component.get("v.recordId");
  var updateIns = component.get("c.updateInsurance");
        
  updateIns.setParams({
    recordId : recordId,
    renewDate : renewDate
   });
  updateIns.setCallback(this, function(response){
   var state = response.getState();
   if(state === "SUCCESS")
   {
//below code is use as speech synthesis which will accept the string and speak 
    if('speechSynthesis' in window)
    {
   var speech = new window.SpeechSynthesisUtterance('Insurance renewed successfully');
     speech.lang = 'en-US';
     window.speechSynthesis.speak(speech);   
     }           
     else
     {
     alert('speechSynthesis not supported');
     }
      component.set("v.showDetail",false);
      $A.get('e.force:refreshView').fire(); 
    }        
   });
  $A.enqueueAction(updateIns);  
  }
})